# Seedance 2.0 Skill OS クイックスタート

> バージョン 6.6.0 · インストールから最初の「演出された」プロンプトまで、およそ 5 分。
> くわしくは [README](../README.md) と [日本語ガイド](README.ja.md) をご覧ください。

## ひとことで言うと

Seedance 2.0 Skill OS は、形容詞を並べるのではなく、映画監督のように Seedance 2.0 を演出する agent skill です。ルールはただひとつ——**モデルを演出する。フレームを一枚ずつ作り込まない。** そのシーンが「何をしているのか」を伝えれば、その意図を実用的なプロンプトへコンパイルします。

## 1. インストール（約 5 分）

このリポジトリを `seedance-20` という**ひとつの**ルートスキルとして入れます。サブスキルと references は相対パスで自動的に読み込まれます。

**Codex（ワンコマンドのインストーラーあり）**

```bash
python scripts/install_codex_skill.py --force
```

リポジトリを `~/.codex/skills/seedance-20`（または `$CODEX_HOME/skills/seedance-20`）へコピーします。Codex を再起動してから `$seedance-20` を呼び出してください。

**GitHub から入れる（リポジトリ URL 指定に対応したクライアントの場合）**

```text
https://github.com/Emily2040/seedance-2.0
```

**手動でコピー（そのほかのクライアント）**

フォルダを、名前を `seedance-20` のままクライアントのスキルディレクトリへコピーします。よくある置き場所は [README のインストール表](../README.md#install) にまとめてあります（保証ではありません。必ずお使いのクライアントでご確認ください）。例：Claude Code `.claude/skills/`、Cursor `.cursor/skills/`、GitHub Copilot `.github/skills/`、Windsurf `.windsurf/skills/`。

> まずは安全から。信頼できる agent クライアントにだけ入れてください。第三者製や素性のわからない agent で使う前に、[SECURITY.md](../SECURITY.md) に必ず目を通してください。

## 2. 目的に合わせてスキルを選ぶ

| こんなとき | まず読み込む |
|---|---|
| まだ漠然としたアイデア | `seedance-interview` |
| はっきりしたシーン | `seedance-prompt` |
| 複数クリップにまたがる物語 | `seedance-sequence` |
| 確定したクリップの続き | `seedance-continuation` |
| 仕上がりが悪い・ブロックされた | `seedance-troubleshoot` |
| キャラクター・ブランド・著名人・実在の人物がからむ | `seedance-copyright` |

## 3. 書きはじめる前に「演出」する——4 つの問い

1. **このシーンは何をしているのか。** 転換か、開示か、感情か、それとも提示か。
2. **カメラはそれをどう語るのか。** 孤独はワイドで、表情はクロースアップで、気づきはプッシュインで。
3. **光は何のために働くのか。** 時間帯、硬さと柔らかさ、暖色と寒色——すべては意図のために。
4. **音は何をするのか。** ほぼ無音か、ひとつの環境音か、あるいは一言のセリフか。

## 4. ひとつの対比

**盛りすぎ（弱い）**

```
壮大でシネマティックな、手紙を読む女性、感情的、美しいライティング、4K
```

**演出（強い）**

```
ミディアムクローズアップ、目線の高さ。手紙を下ろすと手が止まり、ゆっくりとしたプッシュインが寄ってくる。柔らかな窓明かりが顔を素のまま照らす。ほぼ無音、椅子がこすれる音がひとつ。
```

## 5. テイクを無駄にしない 2 つの鉄則

- **参照タグは一字一句そのままに。** `@Image1`、`@Video1`、`@Audio1`、`@图片1`、`@视频1` を翻訳したり書き換えたりしないこと。
- **物語全体を一度の生成で求めない。** まず Clip 01 を生成し、それが「実際に」どう終わったかを見てから、その本当の終わりをもとに Clip 02 を書きます（`seedance-continuation`）。

## 6. 安全

- **コンテンツの安全：** 保護されたキャラクター、著名人、ブランド、ロゴ、楽曲、あるいは実在の人物の顔や声を使うなら、別の言語で隠そうとしないこと。`seedance-copyright` で、オリジナル・ライセンス済み・ポスプロでの差し替えといった安全な形に書き換えます。
- **agent の安全：** このパッケージは**通信を一切行わず、テレメトリも送りません。** スクリプトは決定論的で、オフラインで動きます。API キー、アカウントの Cookie、非公開の素材を、信頼できない agent に貼り付けないでください。[SECURITY.md](../SECURITY.md) を参照。

## 7. さらに深く

- `references/directing-engine.md` — シーンを読み、ひとつの意図を選ぶ（33 のジャンル作例）。
- `references/capability-map.md` — モデルの得意を活かし、既知の弱点を避けて設計する。
- `references/api-workflow.md` — API、プロバイダー、価格、モデル ID（いずれも出典日付つき）。
- `references/examples-by-mode.md` — T2V、I2V、V2V、R2V、FLF2V、編集、延長の例。

---

ほかの言語：[English](QUICKSTART.md) · [中文](QUICKSTART.zh.md) · [한국어](QUICKSTART.ko.md) · [Español](QUICKSTART.es.md) · [Русский](QUICKSTART.ru.md)
