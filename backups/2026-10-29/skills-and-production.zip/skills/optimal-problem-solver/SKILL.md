---
name: optimal-problem-solver
description: "Use when the user asks for the optimal solution (最优解), best path, or how to break a bottleneck (破局); when constraints conflict with each other (quality vs speed vs cost vs stability); when deciding whether a complex approach is worth building at all; or when an abstract idea must become a low-friction execution plan. Produces problem reduction, variable decoupling, a three-path trade-off table with hidden-cost audit, a 10–30 minute minimum-viable test, and an explicit stop-loss trigger."
license: MIT
user-invocable: true
tags: [problem-solving, decision-making, planning]
metadata:
  version: "1.0.0"
  source: "User-provided 上帝之手skill.txt"
---

# Optimal Problem Solver（上帝之手）

A decision-making framework for turning tangled, high-friction problems into decoupled, executable plans — while refusing over-engineered "银河算法" (solutions that look great in theory and cost a fortune in practice).

## When to Use

- User asks for 最优解 / 最佳路径 / 破局 / 怎么选 / 值不值得做.
- User faces a multi-variable dilemma where constraints conflict (quality vs speed, cost vs stability, fidelity vs controllability).
- User wants to judge whether a complex approach is worth implementing.
- User needs an abstract idea or a repeated failure turned into a low-friction execution plan.

## Steps

### 1. Problem Reduction & Boundary Definition（问题降维与边界锚定）

Strip surface noise; define the real optimization problem.

- **Core objective function**: one sentence stating what is actually being maximized or minimized.
- **Hard vs soft constraints**: hard = physical limits, budget, deadlines, platform capability; soft = habits, preferences, taste, "以前都这么做".
- **Scale & context check**: one-off prototype vs a 60-episode pipeline. The optimal answer depends on scale — say which scale you are answering for.

### 2. Variable Decoupling & Sparsification（变量解耦与稀疏化拆解）

When a problem feels unsolvable, too many variables are coupled.

- **Locate the deadlock coupling**: identify the 1–2 variables dragging the whole system down. Usually it is one variable appearing in several disguises.
- **Anchor and split**: fix the shared global parameters first (style baseline, format, budget, identity assets), then split into 2–4 independent sub-modules that can be solved one at a time without interfering.

### 3. Theoretical vs Practical Trade-off Audit（拒绝银河算法）

- **Compare 3 candidate paths** in one Markdown table:

| Path | Ceiling | Setup cost | Fits this scale? | Hidden cost |
|---|---|---|---|---|
| 理论极限解 (perfectionist) | highest | highest | usually no | debugging time, cognitive load, switching cost, maintenance |
| 暴力基准解 (brute force) | low–mid | zero | yes, but scales badly | manual repetition, human error |
| 工程帕累托最优解 (pragmatic) | 80%+ of ideal | ~20% of friction | yes | requires accepting a visible compromise |

- **Hidden cost audit**: name the friction of the perfectionist path in hours, retries, or manual steps. Never recommend it without the number.
- Default recommendation is the pragmatic path unless the user explicitly wants the ceiling.

### 4. Minimum Viable Verification & Action Plan（最小闭环验证与执行路线）

1. **Micro-kernel test**: a 10–30 minute test (one sample, one shot, one clip, one prototype) that proves the core mechanism before full-scale spend.
2. **Step-by-step execution**: 3–5 sequential steps with concrete tools, parameters or actions.
3. **Fallback / stop-loss trigger**: the exact signal at which to abandon this path and switch to the backup, decided *before* spending.

## Output Format

```
结论（一句话最优解）
1. 核心目标函数
2. 硬约束 / 软约束
3. 死锁耦合点（1–2 个）
4. 三路对比表
5. 隐性常数项（完美解的代价，用小时/次数写）
6. 最小闭环测试（10–30 分钟，可验收）
7. 分步执行（3–5 步）
8. 止损条件（什么信号就换路）
```

Keep headings, bullets, one table. No philosophical lecture.

## Gotchas

- Never equate "most complex" with "optimal". If an existing tool or heuristic solves 95% of the real-scale problem in 5 minutes, recommend it over building a system.
- Do not answer a different, easier question than the one asked; restate the objective before optimizing it.
- Do not present a path you cannot execute with the tools actually available in this environment.
- Numbers over adjectives: retries, minutes, yuan, tokens, episodes.
- If the micro-test itself is expensive, shrink the test — do not skip it.
- State what remains unverified. A plan is not evidence.

## 本项目落点（墨团团）

- 反复翻车先按第 2 步找**死锁耦合点**：通常是「身份资产」与「参考图构图层」耦在一起，而不是立场、情绪或镜头数量的问题。
- 三路对比表固定写成：抽图硬碰 / 减变量重写 / 换可拍机制；用小时与重抽次数标隐性成本。
- 最小闭环测试默认是**一段 15–30 秒单镜或单段生成**，验收条件必须写死（身份、方位、动作终态、声音），不达标即止损换路。
- 交付里同时给「已经验证的」与「仍未验证的」，不拿技能安装或方案设计冒充成片通过。
